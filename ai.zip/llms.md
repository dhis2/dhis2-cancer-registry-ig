# dhis2.cancer.registry#0.1.0: DHIS2 Cancer Registry Implementation Guide

## Pages

* [Home](index.md)
* [](ValueSet-TumorQuestionnaire_CRTopographyMorphologyKeyVS-testing.md)
* [ValueSet](ValueSet-FollowUpQuestionnaire_CRVitalStatusVS.md)
* [](ValueSet-SourceQuestionnaire_CRTumorNumberVS-testing.md)
* [](ValueSet-TumorQuestionnaire_CRTopographyGroupVS-testing.md)
* [ValueSet](ValueSet-SourceQuestionnaire_CRTumorNumberVS.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRTumorNumberVS.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRMorphologyGroupVS.md)
* [](ValueSet-TumorQuestionnaire_CRGradeVS-testing.md)
* [](ValueSet-TumorQuestionnaire_CRMorphologyFamilyVS-testing.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRBasisDiagnosisVS.md)
* [Profiles & Mappings](profiles.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRMorphologyResultVS.md)
* [ValueSet](ValueSet-SourceQuestionnaire_CRPlaceholderSourceTypeVS.md)
* [](ValueSet-TumorQuestionnaire_CRMorphology4VS-testing.md)
* [Artifacts Summary](artifacts.md)
* [](ValueSet-TumorQuestionnaire_CRBasisDiagnosisVS-testing.md)
* [Data Quality Checks](data-quality-checks.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRMultiplePrimaryTestVS.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRAddressVS.md)
* [](ValueSet-FollowUpQuestionnaire_CRVitalStatusVS-testing.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRMorphology4VS.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRSiteVS.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRGradeVS.md)
* [Deployment](deployment.md)
* [](ValueSet-SourceQuestionnaire_CRPlaceholderSourceTypeVS-testing.md)
* [](ValueSet-TumorQuestionnaire_CRMorphologyResultVS-testing.md)
* [](ValueSet-TumorQuestionnaire_CRTumorNumberVS-testing.md)
* [](ValueSet-TumorQuestionnaire_CRMorphologyGroupVS-testing.md)
* [](ValueSet-TumorQuestionnaire_CRMultiplePrimaryTestVS-testing.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRMorphologyFamilyVS.md)
* [](ValueSet-TumorQuestionnaire_CRTopographyVS-testing.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRBehaviourVS.md)
* [](ValueSet-TumorQuestionnaire_CRSiteVS-testing.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRTopographyGroupVS.md)
* [](ValueSet-TumorQuestionnaire_CRBehaviourVS-testing.md)
* [References](references.md)
* [](ValueSet-TumorQuestionnaire_CRAddressVS-testing.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRTopographyMorphologyKeyVS.md)
* [License](license.md)
* [ValueSet](ValueSet-TumorQuestionnaire_CRTopographyVS.md)
* [System Design](system-design.md)

## Resources

### CodeSystems

* [CR - Address](CodeSystem-CRAddressCS.md)
* [CR - Basis diagnosis](CodeSystem-CRBasisDiagnosisCS.md)
* [CR - Behaviour](CodeSystem-CRBehaviourCS.md)
* [CR - Grade](CodeSystem-CRGradeCS.md)
* [CR - Morphology4](CodeSystem-CRMorphology4CS.md)
* [CR - Morphology Family](CodeSystem-CRMorphologyFamilyCS.md)
* [CR - Morphology Group](CodeSystem-CRMorphologyGroupCS.md)
* [CR - Morphology result](CodeSystem-CRMorphologyResultCS.md)
* [CR - Multiple primary test](CodeSystem-CRMultiplePrimaryTestCS.md)
* [CR - Placeholder: Source type](CodeSystem-CRPlaceholderSourceTypeCS.md)
* [CR - Sex](CodeSystem-CRSexCS.md)
* [CR - Site](CodeSystem-CRSiteCS.md)
* [CR - Topography](CodeSystem-CRTopographyCS.md)
* [CR - Topography Group](CodeSystem-CRTopographyGroupCS.md)
* [CR - Topography Morphology key](CodeSystem-CRTopographyMorphologyKeyCS.md)
* [CR - Tumor number](CodeSystem-CRTumorNumberCS.md)
* [CR - Vital status](CodeSystem-CRVitalStatusCS.md)
* [Cancer Registry Encounter Types](CodeSystem-cr-encounter-type.md)
* [Cancer Registry Observation Codes](CodeSystem-cr-observation-codes.md)
* [DHIS2 Data Elements](CodeSystem-dhis2-data-elements-cs.md)
* [DHIS2 Tracked Entity Attributes](CodeSystem-dhis2-tracked-entity-attributes-cs.md)

### ValueSets

* [CR - Address value set](ValueSet-CRAddressVS.md)
* [CR - Basis diagnosis value set](ValueSet-CRBasisDiagnosisVS.md)
* [CR - Behaviour value set](ValueSet-CRBehaviourVS.md)
* [CR - Grade value set](ValueSet-CRGradeVS.md)
* [CR - Morphology4 value set](ValueSet-CRMorphology4VS.md)
* [CR - Morphology Family value set](ValueSet-CRMorphologyFamilyVS.md)
* [CR - Morphology Group value set](ValueSet-CRMorphologyGroupVS.md)
* [CR - Morphology result value set](ValueSet-CRMorphologyResultVS.md)
* [CR - Multiple primary test value set](ValueSet-CRMultiplePrimaryTestVS.md)
* [CR - Placeholder: Source type value set](ValueSet-CRPlaceholderSourceTypeVS.md)
* [CR - Sex value set](ValueSet-CRSexVS.md)
* [CR - Site value set](ValueSet-CRSiteVS.md)
* [CR - Topography Group value set](ValueSet-CRTopographyGroupVS.md)
* [CR - Topography Morphology key value set](ValueSet-CRTopographyMorphologyKeyVS.md)
* [CR - Topography value set](ValueSet-CRTopographyVS.md)
* [CR - Tumor number value set](ValueSet-CRTumorNumberVS.md)
* [CR - Vital status value set](ValueSet-CRVitalStatusVS.md)
* [Cancer Registry Encounter Types Value Set](ValueSet-cr-encounter-type-vs.md)
* [Cancer Registry Observation Codes Value Set](ValueSet-cr-observation-codes-vs.md)

### Logicals

* [Cancer Registry](StructureDefinition-CancerRegistry.md)
* [Follow up](StructureDefinition-FollowUp.md)
* [Source](StructureDefinition-Source.md)
* [Tumor](StructureDefinition-Tumor.md)

### Resource Profiles

* [Address](StructureDefinition-cr-address-observation.md)
* [Age at Incidence](StructureDefinition-cr-age-at-incidence-observation.md)
* [Basis of Diagnosis](StructureDefinition-cr-basis-of-diagnosis-observation.md)
* [Behaviour](StructureDefinition-cr-behaviour-observation.md)
* [Cancer Registration EpisodeOfCare](StructureDefinition-cr-cancer-registration-episode.md)
* [Date of Death](StructureDefinition-cr-date-of-death-observation.md)
* [Follow-up Encounter](StructureDefinition-cr-followup-encounter.md)
* [Histological Grade](StructureDefinition-cr-grade-observation.md)
* [Incidence Date](StructureDefinition-cr-incidence-date-observation.md)
* [Morphology](StructureDefinition-cr-morphology-observation.md)
* [Cancer Registry Patient](StructureDefinition-cr-patient.md)
* [Site](StructureDefinition-cr-site-observation.md)
* [Source Notification Encounter](StructureDefinition-cr-source-encounter.md)
* [Source Tumor Number](StructureDefinition-cr-source-tumor-number-observation.md)
* [Source Type](StructureDefinition-cr-source-type-observation.md)
* [Topography](StructureDefinition-cr-topography-observation.md)
* [Tumor Registration Encounter](StructureDefinition-cr-tumor-encounter.md)
* [Tumor Number](StructureDefinition-cr-tumor-number-observation.md)
* [Vital Status](StructureDefinition-cr-vital-status-observation.md)

### Extensions

* [Rare Tumor Classification](StructureDefinition-cr-rare.md)

### ImplementationGuides

* [DHIS2 Cancer Registry Implementation Guide](index.md)

### Questionnaires

* [Follow up Questionnaire](Questionnaire-FollowUpQuestionnaire.md)
* [Source Questionnaire](Questionnaire-SourceQuestionnaire.md)
* [Tumor Questionnaire](Questionnaire-TumorQuestionnaire.md)

### StructureMaps

* [Transform: Cancer Registry Enrollment to EpisodeOfCare](StructureMap-CancerRegistryToEpisode.md)
* [Transform: Cancer Registry Enrollment to Patient](StructureMap-CancerRegistryToPatient.md)
* [Transform: Follow-up Stage to CRFollowUpEncounter + Observations](StructureMap-FollowUpToEncounterAndObservations.md)
* [Transform: Source Stage to CRSourceEncounter + Observations](StructureMap-SourceToEncounterAndObservations.md)
* [Transform: Tumor Stage to CRTumorEncounter + Observations](StructureMap-TumorToEncounterAndObservations.md)

### Examples

* [ExampleFollowUpEncounter (Encounter)](Encounter-ExampleFollowUpEncounter.md)
* [ExampleSourceEncounter (Encounter)](Encounter-ExampleSourceEncounter.md)
* [ExampleTumorEncounter (Encounter)](Encounter-ExampleTumorEncounter.md)
* [ExampleCRRegistrationEpisode (EpisodeOfCare)](EpisodeOfCare-ExampleCRRegistrationEpisode.md)
* [ExampleAgeAtIncidence (Observation)](Observation-ExampleAgeAtIncidence.md)
* [ExampleBasisOfDiagnosis (Observation)](Observation-ExampleBasisOfDiagnosis.md)
* [ExampleBehaviour (Observation)](Observation-ExampleBehaviour.md)
* [ExampleGrade (Observation)](Observation-ExampleGrade.md)
* [ExampleIncidenceDate (Observation)](Observation-ExampleIncidenceDate.md)
* [ExampleMorphology (Observation)](Observation-ExampleMorphology.md)
* [ExampleSite (Observation)](Observation-ExampleSite.md)
* [ExampleSourceTumorNumber (Observation)](Observation-ExampleSourceTumorNumber.md)
* [ExampleSourceType (Observation)](Observation-ExampleSourceType.md)
* [ExampleTopography (Observation)](Observation-ExampleTopography.md)
* [ExampleTumorNumber (Observation)](Observation-ExampleTumorNumber.md)
* [ExampleVitalStatus (Observation)](Observation-ExampleVitalStatus.md)
* [ExampleCRPatient (Patient)](Patient-ExampleCRPatient.md)
